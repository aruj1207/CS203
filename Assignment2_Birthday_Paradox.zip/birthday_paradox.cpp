#include<iostream>
#include<cmath>
using namespace std;
#define e 2.718281828459045
float solve(float k){
     float ratio_fact = powf(365.5/ (float)(365.5 - k), 365.5- k);
     float e_term=powf(e,-k);
     return  1-ratio_fact*e_term;
}

int main(){
        float p;
        cin>>p;
        for(int i=0; ;i++) if(solve(i)>(float)p) {cout<<i<<"\n";break;}
    return 0;
}