README for Birthday Paradox Probability Calculation

Overview
This C++ program calculates the probability that out of k people, at least 2 have a birthday on the same date using the Sterling approximation. The program iterates through values of k until the calculated probability exceeds a given threshold.

Compilation and Execution
1) Compile the program using a C++ compiler (e.g., g++ -o birthday_paradox birthday_paradox.cpp).
2) Run the compiled executable (./birthday_paradox).
3) Enter the desired probability threshold (e.g., 0.507 for the classic birthday paradox).

Algorithm
1) The program defines the Sterling approximation factors: ratio_fact (which the ratio of factorials) and (e)-term (which is the net power of e in the ratio).
2) It iterates through increasing values of k.
3) For each k, it calculates the probability using the formula: (1 - \text{{ratio factor}} \times e)-term.

The program stops when the calculated probability exceeds the specified threshold.