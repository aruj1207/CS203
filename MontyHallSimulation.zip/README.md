## Script Description

The Python script contains the following components:

### Parameters

- `n`: Number of doors available (default value: 3)
- `k`: Number of doors containing the prize (default value: 1)
- `num_trials`: Number of trials to run the simulation (default value: 100,000)

### Functions

- `monty_hall_simulation(num_trials, n, k)`: Performs the Monty Hall simulation with the specified parameters. It calculates the probabilities of winning with sticking (not switching) and winning with switching.
  
### Simulation Execution

- The script checks for valid inputs (ensuring `n` and `k` are positive integers where `n` is greater than `k + 1`).
- If inputs are valid, it runs the simulation using the `monty_hall_simulation` function and prints the probabilities of winning with sticking and switching, along with the ratio of these probabilities.
- If inputs are invalid, it prints an error message prompting the user to enter valid values.

### Surface Plot

- The script generates a surface plot showing the ratio of winning probabilities for different combinations of `n` (number of doors) and `k` (number of doors containing the prize).
- It uses NumPy and Matplotlib libraries for data manipulation and visualization.

## Instructions

1. Ensure you have Python installed on your system along with the required libraries: NumPy and Matplotlib.
2. Open the script in a Python IDE or text editor.
3. Modify the parameters (`n`, `k`, `num_trials`) as needed.
4. Run the script.
5. Review the printed results and the surface plot to understand the behavior of the Monty Hall problem under different conditions.
